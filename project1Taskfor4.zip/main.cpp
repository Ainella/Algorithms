#include <iostream>
#include "Sunday.h"
#include "bruteForce.h"
using namespace std;

int main()
{
    string pattern = "h?l*ld";
    string text = "hello world";

    // Brute-force matching
    bool bruteForceResult = bruteForce(text,pattern);
    cout << "Brute-force match result: " << (bruteForceResult ? "true" : "false") << endl;

    // Sunday matching
    bool sundayResult = sunday(text,pattern);
    cout << "Sunday match result: " << (sundayResult ? "true" : "false") << endl;

    return 0;
}
