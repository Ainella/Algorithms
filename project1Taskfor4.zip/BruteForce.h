#ifndef BruteForce_h
#define BruteForce_h
#include <cstring>
using namespace std;

bool bruteForce(string text,string pat);
#endif // BruteForce_h
