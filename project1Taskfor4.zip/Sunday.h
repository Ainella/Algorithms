#ifndef Sunday_h
#define Sunday_h
#include <cstring>
using namespace std;

bool sunday(string text,string pat);
#endif // Sunday_h
