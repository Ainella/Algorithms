#include <iostream>
#include "bruteForce.h"
using namespace std;

bool bruteForce(string text,string pat)
{
    int m = pat.length();
    int n = text.length();
    int i = 0;
    int j = 0;
    int prev_i = -1;
    int prev_j = -1;

   while (i < n) {
        if (j < m && (text[i] == pat[j] || pat[j] == '?')) {
            i++;
            j++;
        }
        else if (j < m && pat[j] == '*') {
            prev_i = i;
            prev_j = j;
            j++;
        }
        else if (prev_i != -1) {
            i = ++prev_i;
            j = prev_j + 1;
        }
        else {
            return false;
        }
    }

    while (j < m && pat[j] == '*') {
        j++;
    }

    return j == m;
}


