#include <iostream>
#include "Rabin.h"
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;

int main()
{
    int M = 100;
    int K = 10;
    int N = 100;
    // testing
    // initialize M x N picture with 0
    vector<vector<int>> picture(M, vector<int>(N, 0));
    // fill pattern - K x K top-right corner with 1
    for(int i=0; i<K; i++)
    {
        for(int j=0; j<K; j++)
        {
            picture[i][N-K+j] = 1;
        }
    }
    // fill K x K bottom-right corner with 1
    for(int i=0; i<K; i++)
    {
        for(int j=0; j<K; j++)
        {
            picture[M-K+i][N-K+j] = 1;
        }
    }
    // picture [0][N-K + 0] = 1;
    // picture [0][N-K + 1] = 1;
    // picture [1][N-K + 0] = 1;
    // picture [1][N-K + 1] = 1;
    // picture [M-K + 0][N-K + 0] = 1;
    // picture [M-K + 1][N-K + 1] = 1;
    // picture [M-K + 0][N-K + 0] = 1;
    // picture [M-K + 1][N-K + 1] = 1;

    bool isDuplicate = rabinKarpModified(picture, M, N, K);

    if (isDuplicate)
    {
        cout << "Duplicate top-right corner found in the picture." << endl;
    }
    else
    {
        cout << "No duplicate top-right corner found in the picture." << endl;
    }


    // benchmark
    // picture size from 100 x 100 to 100 x 1000
    for(int N=100; N<=1000; N+=100)
    {
        vector<vector<int>> picture(M,  vector<int>(N, 0));
        for(int i=0; i<K; i++)
        {
            for(int j=0; j<K; j++)
            {
                picture[i][N-K+j] = 1;
            }
        }
        for(int i=0; i<K; i++)
        {
            for(int j=0; j<K; j++)
            {
                picture[M-K+i][N-K+j] = 1;
            }
        }

        auto start = chrono::steady_clock::now();
        int r = rabinKarpModified(picture, M, N, K);
        auto end = chrono::steady_clock::now();
        chrono::nanoseconds karp_time_taken =
            chrono::duration_cast<chrono::nanoseconds>(end - start);

        cout<< karp_time_taken.count() << endl;
    }
    return 0;
}
