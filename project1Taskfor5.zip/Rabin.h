#ifndef Rabin_h
#define Rabin_h
#include <vector>
using namespace std;

bool rabinKarpModified(vector<vector<int>> picture, int M, int N, int K);
#endif // Rabin_h
