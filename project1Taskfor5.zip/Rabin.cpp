#include <iostream>
#include "Rabin.h"
#include <vector>
using namespace std;

bool compareCorners(vector<vector<int>> picture, int x, int y, int K) {
    for (int i = 0; i < K; i++) {
        for (int j = 0; j < K; j++) {
            if (picture[x + i][y + j] != picture[i][j]) {
                return false;
            }
        }
    }
    return true;
}

bool rabinKarpModified(vector<vector<int>> picture, int M, int N, int K) {
    // Calculate hash of the top-right corner
    int cornerHash = 0;
    for (int i = 0; i < K; i++) {
        for (int j = 0; j < K; j++) {
            cornerHash = (cornerHash << 1) | picture[i][N - K + j];
        }
    }

    // Initialize rolling hash variables
    int rollingHash = 0;
    int mask = (1 << K) - 1; // Bit mask to extract K bits

    // Calculate initial rolling hash for the first window
    for (int i = 0; i < K; i++) {
        for (int j = 0; j < K; j++) {
            rollingHash = (rollingHash << 1) | picture[i][j];
        }
    }

    // Check for duplicate corners
    for (int i = 0; i <= M - K; i++) {
        for (int j = 0; j <= N - K; j++) {
            if (i > 0) {
                // Update rolling hash by removing the top row
                rollingHash ^= (picture[i - 1][N - K] << (K - 1));
                rollingHash = (rollingHash << 1) | picture[i + K - 1][N - K];
            }
            if (rollingHash == cornerHash) {
                // Perform pixel-by-pixel comparison to confirm duplicate
                if (compareCorners(picture, i, j, K)) {
                    return true;
                }
            }
        }
    }

    return false;
}
