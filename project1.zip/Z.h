#ifndef Z_h
#define Z_h

int z_algorithm(char *text,char *pat,int ntext,int npat);
#endif // Z_h
