#include <iostream>
#include "bruteForce.h"

int bruteForce(char *text,char *pat,int ntext,int npat)
{
    int count = 0;
    for(int i = 0; i <= ntext-npat; i++)
    {
        int j = 0;
        for(; j < npat; j++)
        {
            if(text[i+j]!=pat[j])
            {
                break;
            }
        }
        if(j == npat)
            //return i;
            count++;
    }
    //return -1;
    return count;
}
