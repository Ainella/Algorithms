#include <iostream>
#include "Z.h"

void getZarr(char *s, int n, int *z)
{
    int L = 0, R = 0;
    for (int i = 1; i < n; i++)
    {
        if (i > R)
        {
            L = R = i;
            while (R < n && s[R-L] == s[R])
            {
                R++;
            }
            z[i] = R-L;
            R--;
        }
        else
        {
            int k = i-L;
            if (z[k] < R-i+1)
            {
                z[i] = z[k];
            }
            else
            {
                L = i;
                while (R < n && s[R-L] == s[R])
                {
                    R++;
                }
                z[i] = R-L;
                R--;
            }
        }
    }
}

int z_algorithm(char *text, char *pat, int ntext, int npat)
{
    int count = 0;
    int n = ntext + npat + 1;
    char *concat = new char[n];
    for (int i = 0; i < npat; i++)
        concat[i] = pat[i];
    concat[npat] = 0;
    for (int i = 0; i < ntext; i++)
        concat[npat + i + 1] = text[i];

    int *z = new int[n];
    getZarr(concat, n, z);

    // now looping through Z array for matching condition
    for (int i = 1; i < n; ++i)
    {
        // if Z[i] (matched region) is equal to pattern
        // length we got the pattern
        if (z[i] == npat)
        {
            count++;
            //delete[] concat;
            //delete[] z;
            //return i - npat - 1;
        }
    }
    delete[] concat;
    delete[] z;
    //return -1;
    return count;
}
