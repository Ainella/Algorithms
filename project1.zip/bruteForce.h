#ifndef bruteForce_h
#define bruteForce_h

int bruteForce(char *text,char *pat,int ntext,int npat);
#endif // bruteForce#define bruteForce.h
