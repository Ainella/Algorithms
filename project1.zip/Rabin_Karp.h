#ifndef KarpRabin_h
#define KarpRabin_h

int rabinKarp(char *text,char *pat,int ntext,int npat);
#endif
