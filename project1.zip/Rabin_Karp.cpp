#include <iostream>
#include "Rabin_Karp.h"
#define d 256
#define q INT_MAX

int rabinKarp(char *text,char *pat,int ntext,int npat)
{
    int count = 0;
    int patHash = 0;
    int textHash = 0;
    int base = 1;

    for (int i = 0; i < npat - 1; i++)
        base = (base * d) % q;


    for (int i = 0; i < npat; i++)
    {
        patHash = (d * patHash + pat[i]) % q;
        textHash = (d * textHash + text[i]) % q;
    }


    for (int i = 0; i <= ntext - npat; i++)
    {
        if (patHash == textHash)
        {
            int j = 0;
            for (; j < npat; j++)
            {
                if (text[i + j] != pat[j])
                    break;
            }
            if (j == npat){
                count++;
                //return i;
            }
        }

        if (i < ntext - npat)
        {
            textHash = (d * (textHash - text[i] * base) + text[i + npat]) % q;

            if (textHash < 0)
                textHash = (textHash + q);
        }
    }
    //return -1;
    return count;
}
