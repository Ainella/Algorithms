#ifndef Sunday_h
#define Sunday_h

int sunday(char *text,char *pat,int ntext,int npat);
#endif
