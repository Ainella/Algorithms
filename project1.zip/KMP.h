#ifndef KMP_h
#define KMP_h

int kmp(char *text,char *pat,int ntext,int npat);
#endif // KMP_h
