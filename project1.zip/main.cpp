#include <iostream>
#include <cstring>
#include "bruteForce.h"
#include "Sunday.h"
#include "Rabin_Karp.h"
#include "KMP.h"
#include "Z.h"
#include "FSM.h"
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <fstream>
#define TEXTSIZE 8000
using namespace std;

void TestbruteForce()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = bruteForce(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "BruteForce test passed" << endl;
    else
        cout << "BruteForce test failed" << endl;
}

void Testsunday()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = sunday(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "Sunday test passed" << endl;
    else
        cout << "Sunday test failed" << endl;
}

void TestrabinKarp()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = rabinKarp(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "Rabin-Karp test passed" << endl;
    else
        cout << "Rabin-Karp test failed" << endl;
}

void Testkmp()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = kmp(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "KMP test passed" << endl;
    else
        cout << "KMP test failed" << endl;
}

void Testz_algorithm()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = z_algorithm(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "Z_algorithm test passed" << endl;
    else
        cout << "Z_algorithm test failed" << endl;
}

void Testfsm()
{
    char text[] = "abcdaabbcccdefg";
    char pat[] = "cde";
    int p = fsm(text,pat,strlen(text),strlen(pat));
    if(p==1)
        cout << "FSM test passed" << endl;
    else
        cout << "FSM test failed" << endl;
}

void readfile(string filename, char *text,int n)
{
    fstream F;
    F.open(filename);
    if (F)
    {
        char c;
        for (int i=0; i < n; i++)
        {
            F>>c;
            text[i] = c;
        }
        F.close();
    }
    else
        throw exception();
}

int main()
{
    TestbruteForce();
    Testsunday();
    TestrabinKarp();
    Testkmp();
    Testz_algorithm();
    Testfsm();
    chrono::nanoseconds zero(0);
    chrono::nanoseconds bruteForceresults[20];
    chrono::nanoseconds sundayresults[20];
    chrono::nanoseconds rabinKarpresults[20];
    chrono::nanoseconds kmpresults[20];
    chrono::nanoseconds z_aresultsresults[20];
    chrono::nanoseconds fsmresults[20];
    fill(bruteForceresults,bruteForceresults+20,zero);
    fill(sundayresults,sundayresults+20,zero);
    fill(rabinKarpresults,rabinKarpresults+20,zero);
    fill(kmpresults,kmpresults+20,zero);
    fill(z_aresultsresults,z_aresultsresults+20,zero);
    fill(fsmresults,fsmresults+20,zero);
    char text[TEXTSIZE] = {};
    readfile("chapter.txt",text,TEXTSIZE);


    long times = 5;
    for (long i = 1 ; i <= times ; i++)
    {
        char pat[200] = {};
        readfile("pattern" + to_string(i)  + ".txt",pat,200);
        for(int i=0; i<20; i++)
        {
            int n = 10*(i+1);

            auto start = chrono::steady_clock::now();
            bruteForce(text,pat,TEXTSIZE,n);
            auto end = chrono::steady_clock::now();
            chrono::nanoseconds time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            bruteForceresults[i]+=time_taken;


            start = chrono::steady_clock::now();
            sunday(text,pat,TEXTSIZE,n);
            end = chrono::steady_clock::now();
            time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            sundayresults[i]+=time_taken;


            start = chrono::steady_clock::now();
            rabinKarp(text,pat,TEXTSIZE,n);
            end = chrono::steady_clock::now();
            time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            rabinKarpresults[i]+=time_taken;


            start = std::chrono::steady_clock::now();
            kmp(text,pat,TEXTSIZE,n);
            end = chrono::steady_clock::now();
            time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            kmpresults[i]+=time_taken;


            start = std::chrono::steady_clock::now();
            z_algorithm(text,pat,TEXTSIZE,n);
            end = chrono::steady_clock::now();
            time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            z_aresultsresults[i]+=time_taken;


            start = std::chrono::steady_clock::now();
            fsm(text,pat,TEXTSIZE,n);
            end = chrono::steady_clock::now();
            time_taken =
                chrono::duration_cast<chrono::nanoseconds>(end - start);
            fsmresults[i]+=time_taken;
        }
    }
    for(int i=0; i<20; i++)
    {
        int n = 10*(i+1);
        cout << n << " ";
        cout << bruteForceresults[i].count()/times << " ";
        cout << sundayresults[i].count()/times << " ";
        cout << rabinKarpresults[i].count()/times << " ";
        cout << kmpresults[i].count()/times << " ";
        cout << z_aresultsresults[i].count()/times << " ";
        cout << fsmresults[i].count()/times << endl;
    }

    //B KMP is at least twice as fast as Rabin-Karp.
    readfile("TEXTFORKARP.txt",text,TEXTSIZE);
    char pat[20] = {};
    readfile("PATFORKARP.txt",pat,20);

    auto start = chrono::steady_clock::now();
    int k = kmp(text,pat,TEXTSIZE,20);
    auto end = chrono::steady_clock::now();
    chrono::nanoseconds kmp_time_taken =
        chrono::duration_cast<chrono::nanoseconds>(end - start);

    start = chrono::steady_clock::now();
    int r = rabinKarp(text,pat,TEXTSIZE,20);
    end = chrono::steady_clock::now();
    chrono::nanoseconds karp_time_taken =
        chrono::duration_cast<chrono::nanoseconds>(end - start);

    start = chrono::steady_clock::now();
    int s = sunday(text,pat,TEXTSIZE,20);
    end = chrono::steady_clock::now();
    chrono::nanoseconds sunday_time_taken =
        chrono::duration_cast<chrono::nanoseconds>(end - start);

    cout <<  kmp_time_taken.count() << endl;
    cout << karp_time_taken.count() << endl;

    cout <<  sunday_time_taken.count() << endl;
    cout << karp_time_taken.count() << endl;

    cout << k << endl;
    cout << r << endl;

    cout << s << endl;
    cout << r << endl;
    return 0;
}
