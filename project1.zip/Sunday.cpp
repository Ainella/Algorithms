#include <iostream>
#include "Sunday.h"
#define d 256

int sunday(char *text,char *pat,int ntext,int npat)
{
    int count = 0;
    if(npat==0)
        //return 0;
        return 1;

    if(ntext<npat)
        return 0;

    int table[d];
    for(int i = 0; i<d; ++i)
        table[i] = -1;
    for(int i=0; i<npat; i++)
    {
        char c = pat[i];
        table[(int)c]=i;
    }

    int i = 0;
    while(i<=ntext-npat)
    {
        int j = 0;
        for(; j<npat; ++j)
        {
            if(text[i+j] != pat[j])
            {
                char c = text[i+npat];
                if(table[(int)c]==-1)
                    i += npat+1;
                else
                    i += npat-table[(int)c];
                break;
            }
        }
        if(j == npat)
        {
            //return i;
            count++;
            i++;
        }
    }
    //return -1;
    return count;
}
