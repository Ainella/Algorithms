#ifndef fsm_h
#define fsm_h

int fsm(char *text,char *pat,int ntext,int npat);
#endif // fsm_h
