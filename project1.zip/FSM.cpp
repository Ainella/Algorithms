#include <iostream>
#include "FSM.h"
#define d 256

int getNextState(char *pat, int M, int state, int x)
{
    if (state < M && x == pat[state])
        return state+1;

    int ns, i;

    for (ns = state; ns > 0; ns--)
    {
        if (pat[ns-1] == x)
        {
            for (i = 0; i < ns-1; i++)
                if (pat[i] != pat[state-ns+1+i])
                    break;
            if (i == ns-1)
                return ns;
        }
    }

    return 0;
}

void computeTF(char *pat, int M, int** TF)
{
    int state, x;
    for (state = 0; state <= M; ++state)
        for (x = 0; x < d; ++x)
            TF[state][x] = getNextState(pat, M, state, x);
}


int fsm(char *text,char *pat,int ntext,int npat)
{
    int count = 0;
    int** TF = new int*[npat+1];

    for (int i = 0; i < npat+1; i++)
        TF[i] = new int[d];

    computeTF(pat, npat, TF);

    int i, state=0;
    for (i = 0; i < ntext; i++)
    {
        state = TF[state][text[i]];
        if (state == npat)
        {
            /*for(int i=0; i<npat+1; i++)
            {
                delete[] TF[i];
            }
            delete[] TF;
            return i-npat+1;*/
            count++;
        }
    }
    for(int i=0; i<npat+1; i++)
    {
        delete[] TF[i];
    }
    delete[] TF;
    //return -1;
    return count;
}



